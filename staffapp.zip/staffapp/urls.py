from . import views
from django.urls import path
urlpatterns = [
path('aboutus',views.aboutus,name='aboutus'),
path('',views.index,name='index'),

]