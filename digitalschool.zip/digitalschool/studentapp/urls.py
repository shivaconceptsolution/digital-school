from django.urls import path
from . import views
urlpatterns = [
    path('',views.index,name='index'),
    path('addition',views.addition,name='addition'),
    path('home',views.home,name='home'),
    path('about',views.about,name='about'),
    path("login", views.login_request, name="login"),
    path("logout", views.logout_request, name= "logout")

    ]