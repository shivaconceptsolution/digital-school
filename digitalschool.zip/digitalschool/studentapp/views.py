from django.shortcuts import render
from django.http import HttpResponse
def index(request):
    if request.method=="POST":

        name = request.POST["txtfname"]
        gender = request.POST["gender"]
        branch = request.POST.getlist("branch")
        course = request.POST["course"]
        loc = request.POST.getlist("loc")
        query = request.POST["query"]
        s = "" 
        l = ""
        for data in branch:
            s = s + data + " "
        for data in loc:
            l = l + data + " "    
       

        return render(request,"studentapp/index.html",{"name":name,"gender":gender,"branch":s,"course":course,"loc":l,"query":query,"locnew":loc})
    else:
        return render(request,"studentapp/index.html")    

def addition(request):
    a=100
    b=200
    c=a+b
    return HttpResponse("Result is "+str(c))
