from django.shortcuts import render,redirect
from django.http import HttpResponse
from .forms import StudentForm
from django.contrib import messages
from django.contrib.auth import login, authenticate,logout   #add this
from django.contrib import messages
from django.contrib.auth.forms import AuthenticationForm #add this
def index(request):
    if request.method=="POST":

        name = request.POST["txtfname"]
        gender = request.POST["gender"]
        branch = request.POST.getlist("branch")
        course = request.POST["course"]
        loc = request.POST.getlist("loc")
        query = request.POST["query"]
        s = "" 
        l = ""
        for data in branch:
            s = s + data + " "
        for data in loc:
            l = l + data + " "    
       
        f = open("d://info.doc","a")
        f.write("Name:" + name + "\n")
        f.write("Gender:" + gender + "\n")
        f.write("branch" + s + "\n")
        f.write("Location" + l + "\n")
        f.write("query" + query.strip() + "\n")
        f.close()
        return render(request,"studentapp/index.html",{"name":name,"gender":gender,"branch":s,"course":course,"loc":l,"query":query,"locnew":loc})
    else:
        return render(request,"studentapp/index.html")    

def addition(request):
    a=100
    b=200
    c=a+b
    return HttpResponse("Result is "+str(c))


def home(request):
    if request.method=="POST":
        form = StudentForm(request.POST)
        if form.is_valid():
            user = form.save()
            return HttpResponse("Reg successfully")
    form = StudentForm()
    return render(request,"studentapp/home.html",{"reg":form})


def about(request):
    return render(request,"studentapp/about.html")
    
def login_request(request):
    if request.method=="POST":
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None:
                login(request, user)
                return redirect("/student/about")
            else:
                return HttpResponse("Invalid userid and Password")
        else:
            return HttpResponse("Invalid userid and Password")
    form = AuthenticationForm()
    return render(request=request, template_name="studentapp/login.html", context={"login_form":form})
def logout_request(request):
    logout(request)
    return redirect("/student/login")
