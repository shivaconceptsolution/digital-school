from django.urls import path
from .import views
from teacher.views import Index,ViewState,ViewCity,Addcountry,ContactFormView,Updatecountry,Deletecountry

urlpatterns = [
    path('',Index.as_view()),
    path('viewstate',ViewState.as_view()),
    path('viewcity',ViewCity.as_view()),
    path('addcountry',Addcountry.as_view()),
    path('contact',ContactFormView.as_view()),
    path('<pk>/updatecountry',Updatecountry.as_view()),
    path('<pk>/deletecountry',Deletecountry.as_view()),
    path('country',views.country,name='country'),
    path('state',views.state,name='state'),
    path('city',views.city,name='city')

]