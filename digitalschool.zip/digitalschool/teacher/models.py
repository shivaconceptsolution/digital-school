from django.db import models
from django.http import HttpResponse
from django.shortcuts import redirect

class Country(models.Model):
     countryname=models.CharField(max_length=20)
     def __str__(self):
         return self.countryname
     def get_absolute_url(self):
        pass  

class State(models.Model):
    statename=models.CharField(max_length=20)
    country=models.ForeignKey(Country,on_delete=models.CASCADE)
    def __str__(self):
        return self.statename + " " +str(self.country_id);	

class City(models.Model):
    cityname=models.CharField(max_length=20)
    state=models.ForeignKey(State,on_delete=models.CASCADE)
    def __str__(self):
        return self.cityname + " "+ str(self.state_id)

class Contact(models.Model):
    name=models.CharField(max_length=20)
    message=models.CharField(max_length=50)
    email=models.CharField(max_length=50)
    mobile=models.CharField(max_length=12)
    def __str__(self):
        return "name is "+self.name+ " message "+self.message + " email"+self.email