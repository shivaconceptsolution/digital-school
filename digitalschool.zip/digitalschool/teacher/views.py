from django.views import View
from django.shortcuts import render
from .models import Country,State,Contact,City
from django.views.generic.edit import CreateView,FormView,UpdateView,DeleteView
from teacher.forms import ContactForm

class Index(View):
   def get(self,request):
    c = Country.objects.all()
    return render(request,"teacher/index.html",{'res':c})
   

class ViewState(View):
   def get(self,request):
    c = Country.objects.get(pk=request.GET["q"])
    s = c.state_set.all()
    return render(request,"teacher/viewstate.html",{"res":s})

class ViewCity(View):
  def get(self,request):
    s = State.objects.get(pk=request.GET["q"])
    c = s.city_set.all()
    return render(request,"teacher/viewcity.html",{"res":c})

class Addcountry(CreateView):
    model = Country
    fields=['countryname']
    success_url = '/teacher'
class Updatecountry(UpdateView):
    model = Country
    fields=['countryname']
    template_name_suffix = '_update_form'
    success_url = '/teacher'
class Deletecountry(DeleteView):
    model = Country
    success_url = '/teacher'    
class ContactFormView(FormView):
    template_name = 'teacher/contact.html'
    form_class = ContactForm
    success_url = '/teacher'

    def form_valid(self, form):
        # This method is called when valid form data has been POSTed.
        # It should return an HttpResponse.
        obj = Contact(name=form.cleaned_data['name'],message=form.cleaned_data['message'],email=form.cleaned_data['email'],mobile=form.cleaned_data['mobile'])
        obj.save()
        return super().form_valid(form)    


def country(request):
    c = Country.objects.all()
    return render(request,"teacher/country.html",{'res':c})
def state(request):
    cid = request.GET['cid']
    st = State.objects.filter(country_id=cid)
    return render(request,"teacher/state.html",{'res':st})    
def city(request):
    cid = request.GET['cid']
    st = City.objects.filter(state_id=cid)
    return render(request,"teacher/city.html",{'res':st})     