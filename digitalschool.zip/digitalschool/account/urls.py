from . import views
from django.urls import path
from account.views import Index
urlpatterns = [
path('',Index.as_view()),
path('logincode',views.logincode,name='logincode'),
path('contact',views.contact,name='contact'),
path('dashboard',views.dashboard,name='dashboard'),
path('logoutcode',views.logoutcode,name='logoutcode'),
path('editprofile',views.editprofile,name='editprofile'),
path('insert',views.insert,name='insert'),
path('reg',views.reg,name='reg'),    
path('regcode',views.regcode,name='regcode'),
path('fupload',views.fupload,name='fupload'),
path('testapi',views.testapi,name='testapi')

]