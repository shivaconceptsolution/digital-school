from django.views import View
from django.shortcuts import render,redirect
from . models import Register,Student,Fupload 
from django.contrib.auth.models import User
from django.contrib.auth import authenticate,login,logout
from django.contrib.auth.decorators import login_required
from django.http import HttpResponse
from django.core.files.storage import FileSystemStorage
import requests
class Index(View):
  def get(self,request):
       return render(request,"account/index.html")  
  def post(self,request):
    
        user = User.objects.create_user(request.POST["txtuser"], request.POST["txtemail"], request.POST["txtpass"])
        user.first_name=request.POST["txtfname"]
        user.last_name=request.POST["txtlname"]
        user.save()
        return render(request,"account/index.html",{"res":"Register successfully"})
 
   

def logincode(request):
    if request.method == "POST":
        user = authenticate(username=request.POST["txtuser"], password=request.POST["txtpass"])
       # r = Register.objects.filter(uname=request.POST["txtuser"],upass=request.POST["txtpass"]).values_list('id')
        if user is not None:
            login(request, user)
            request.session["uname"] = request.POST["txtuser"]
            return redirect('/account/dashboard')
        else:
            res = "Invaid userid and password"
        return render(request,"account/about.html",{"key":res})        
    return render(request,"account/about.html")   

def contact(request):
    return render(request,"account/contact.html") 
@login_required(login_url='/account/logincode')    
def dashboard(request):
    return render(request,"account/dashboard.html")
   

def editprofile(request):
    uid = request.session["uid"]
    data = Register.objects.get(pk=uid)
    if request.method=="POST":
         data.uname = request.POST["txtname"]
         data.upass = request.POST["txtpass"]
         data.fname = request.POST["txtfname"]
         data.mobile = request.POST["txtmobile"]
         data.save()
         return redirect('dashboard')
    else:
        return render(request,"account/profile.html",{"res":data})             
def logoutcode(request):
    #del request.session["uname"] 
    logout(request)
    return redirect('/account')     


def insert(request):
    s = Student(rno=1234,sname='xyz',branch='cs',fees=45000)
    s.save()
    return HttpResponse("Data Inserted Successfully")

def reg(request):
  return render(request,"account/reg.html")
def regcode(request):
     chkusername = Register.objects.filter(uname=request.POST.get("uid"))
     checkemail = Register.objects.filter(uemail=request.POST["txtemail"])
     if (chkusername.count()>0):
         res = "username already exist"
     elif checkemail.count()>0:
         res = "email already exist"
     else:
         r = Register(uname=request.POST.get("uid"),upass=request.POST.get("upass"),fname=request.POST.get("fname"),mobile=request.POST.get("mobile"))
         r.save()
         return HttpResponse("data inserted successfully")  
 
def fupload(request):
    if request.method=="POST":
        f = request.FILES["file"]
        fs = FileSystemStorage()
        fs.save(f.name,f)
        obj = Fupload(filepath=f.name)
        obj.save()
        return render(request,"account/fupload.html",{"res":Fupload.objects.all()})
    return render(request,"account/fupload.html")


def testapi(request):
    response = requests.get('http://127.0.0.1:8000/tutors') 
    tutor = response.json()
    return render(request,"account/test.html",{'data':tutor})