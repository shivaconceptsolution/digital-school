from django.shortcuts import render
from django.http import HttpResponse
def addition(request):
    if request.method == "POST":
        a = request.POST["txtnum1"]
        b = request.POST["txtnum2"]
        c=0
        if request.POST["btnsubmit"] == "+":
           c = int(a)+int(b)
        elif request.POST.get("btnsubmit") == "-":
           c = int(a)-int(b)   
        elif request.POST.get("btnsubmit") == "*":
           c = int(a)*int(b) 
        else:
           c = int(a)/int(b)

        return render(request,"staffapp/addition.html",{"key":"Result is "+str(c),"txt1":a,"txt2":b})
    else:    
       return render(request,"staffapp/addition.html")    