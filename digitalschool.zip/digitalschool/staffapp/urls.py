from . import views,staffviews,newstaffviews
from django.urls import path
urlpatterns = [
path('aboutus',staffviews.aboutus,name='aboutus'),
path('',views.index,name='index'),
path('addition',newstaffviews.addition,name='addition'),
path('ajax',views.ajaxexample,name='ajaxexample'),
path('ajaxcode',views.ajaxcode,name='ajaxcode')

]