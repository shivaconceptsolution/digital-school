from django.shortcuts import render
from django.http import HttpResponse
from account.models import Student
def index(request):
    return render(request,"staffapp/index.html")

def ajaxexample(request):
    return render(request,"staffapp/ajaxexample.html")

def ajaxcode(request):
    data = request.GET["q"]
   # res = Student.objects.filter(sname__contains=data)
  #  res = Student.objects.filter(sname__startswith=data)
    res = Student.objects.filter(sname__endswith=data)
    return render(request,"staffapp/ajaxcode.html",{'key':res})